export interface CadenceItem {
  id: string;
  title: string;
  detail: string;
  duration: string;
}

export const WEEKLY_RITUALS: CadenceItem[] = [
  {
    id: "think",
    title: "Blok berpikir",
    detail: "3 jam tanpa rapat. Strategi, memo, atau masalah yang hanya CEO yang bisa urus.",
    duration: "3 jam",
  },
  {
    id: "staff",
    title: "Rapat kepemimpinan",
    detail: "Scorecard, 5 prioritas, hambatan, keputusan. Tanpa slide status.",
    duration: "90 mnt",
  },
  {
    id: "ones",
    title: "1:1 laporan langsung",
    detail: "Agenda milik mereka. Dengarkan, tantang, buka jalan.",
    duration: "45–60 mnt / orang",
  },
  {
    id: "customer",
    title: "Kontak pelanggan",
    detail: "Minimal 3 percakapan nyata. Catat kata-kata mereka.",
    duration: "3 sesi",
  },
  {
    id: "cash",
    title: "Kas & angka",
    detail: "Runway, koleksi, burn, 3 metrik yang bergerak.",
    duration: "45 mnt",
  },
  {
    id: "people",
    title: "Sinyal orang",
    detail: "Siapa yang naik, macet, atau harus diputuskan. Jangan tunda.",
    duration: "30 mnt",
  },
  {
    id: "write",
    title: "Tulis & putuskan",
    detail: "Log keputusan, memo, atau narasi satu halaman. Menulis memaksa jernih.",
    duration: "60 mnt",
  },
  {
    id: "review",
    title: "Tinjauan CEO",
    detail: "Apa yang hanya saya yang bisa? Apa yang harus berhenti? Energi 1–5.",
    duration: "45 mnt",
  },
];

export const DAILY_RITUALS: CadenceItem[] = [
  {
    id: "one-thing",
    title: "Satu pekerjaan CEO",
    detail: "Sebelum inbox: satu hal yang mengubah perusahaan, bukan yang merapikan hari.",
    duration: "90 mnt",
  },
  {
    id: "walk",
    title: "Putaran singkat",
    detail: "Dua percakapan tidak terencana. Sinyal hidup ada di koridor, bukan di dashboard.",
    duration: "20 mnt",
  },
  {
    id: "close",
    title: "Tutup hari",
    detail: "Tulis 3 baris: yang selesai, yang macet, taruhan besok.",
    duration: "10 mnt",
  },
];

export const MONTHLY_RITUALS: CadenceItem[] = [
  {
    id: "strategy-hour",
    title: "Uji strategi",
    detail: "Baca narasi satu halaman. Apa yang tidak lagi benar? Apa yang belum diuji?",
    duration: "2 jam",
  },
  {
    id: "talent-map",
    title: "Peta bakat",
    detail: "Kinerja × potensi untuk laporan langsung dan kursi kunci di bawah mereka.",
    duration: "90 mnt",
  },
  {
    id: "calendar-audit",
    title: "Audit kalender",
    detail: "Persentase berpikir vs firefighting vs theater. Target theater mendekati nol.",
    duration: "45 mnt",
  },
  {
    id: "pnl",
    title: "P&L dan alokasi",
    detail: "Cocokkan pengeluaran dengan prioritas. Bunuh yang tidak mendukung taruhan.",
    duration: "2 jam",
  },
];

export const QUARTERLY_RITUALS: CadenceItem[] = [
  {
    id: "offsite",
    title: "Offsite tim senior",
    detail: "Satu diagnosis bersama, 3–5 prioritas kuartal, kursi kunci, dan taruhan yang dibunuh.",
    duration: "1–2 hari",
  },
  {
    id: "board",
    title: "Board yang jujur",
    detail: "Memo sebelum rapat. Kabar buruk di halaman satu. Minta bantuan yang spesifik.",
    duration: "1 hari + memo",
  },
  {
    id: "talent-review",
    title: "Talent review",
    detail: "Keep / coach / move / cut. Promosi dan pipa kepemimpinan.",
    duration: "setengah hari",
  },
  {
    id: "strategy-refresh",
    title: "Segarkan taruhan",
    detail: "Asumsi mana yang mati. Pasar mana yang kita tinggalkan. Modal ke mana.",
    duration: "setengah hari",
  },
];

export const MEETING_TYPES = [
  {
    name: "1:1",
    cadence: "Mingguan / 2 mingguan",
    purpose: "Perkembangan orang, hambatan, hubungan. Bukan status.",
    rule: "Agenda milik laporan langsung. CEO mendengar 70% waktu.",
  },
  {
    name: "Rapat staf",
    cadence: "Mingguan",
    purpose: "Angka, prioritas, keputusan lintas fungsi.",
    rule: "Bahan dibaca sebelumnya. Rapat untuk memutuskan, bukan menginformasikan.",
  },
  {
    name: "Skip-level",
    cadence: "Bulanan",
    purpose: "Sinyal yang tidak sampai lewat rantai komando.",
    rule: "Dengar. Jangan merusak wewenang manajer di depan timnya.",
  },
  {
    name: "Pelanggan",
    cadence: "Mingguan",
    purpose: "Realitas di luar gedung.",
    rule: "CEO hadir. Jangan hanya delegasikan ke sales atau CS.",
  },
  {
    name: "Board",
    cadence: "Kuartalan",
    purpose: "Tata kelola, modal, tantangan strategi.",
    rule: "Memo 4–8 halaman 72 jam sebelumnya. Rapat bukan teater slide.",
  },
  {
    name: "Offsite strategi",
    cadence: "Kuartalan",
    purpose: "Pilihan yang tidak muat di rapat staf.",
    rule: "Diagnosis dulu, opsi, baru keputusan. Larang daftar proyek.",
  },
];
